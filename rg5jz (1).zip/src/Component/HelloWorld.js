import React, { Component } from "react";

class Hello extends Component {
  render() {
    return <div>Hello World</div>;
  }
}
export default Hello;
